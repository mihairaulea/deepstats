A Pen created at CodePen.io. You can find this one at https://codepen.io/AhmedMaroOf/pen/BvrMMZ.

 Awesome search bar using CSS and HTML 