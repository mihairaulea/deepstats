A Pen created at CodePen.io. You can find this one at https://codepen.io/heypablete/pen/qdIsm.

 These is a "&lt;Table&gt; Responsive" with CSS3 transition, box-shadow, transform properties. Responsive Web Design technology & without JS.

The GitHub code:
https://github.com/PableraShow/Table-Responsive

Official Site:
http://pablerashow.github.io/